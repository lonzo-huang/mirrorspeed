# MirrorSpeed Portal — Patch Overlay (v3)

Three things this patch does:

1. **All marketing pages** (`/`, `/cn`, `/en`, `/download`, `/pricing`, `/servers`,
   `/blog`, `/blog/[slug]`, `/help`, `/support`, `/privacy`, `/terms`,
   `/cookies`, `/disclaimer`) → share the same dark-glass landing aesthetic
   via `<LandingChrome>` + gradient cyan `<h1>` + Unbounded heading font.
2. **Auth + Dashboard + Admin** → outer wrapper restyled to match the dark
   theme (background grid, glow orbs, cyan accents). Form logic, useState,
   useEffect, Supabase calls, router calls, API endpoints **strictly
   untouched**.
3. **Site-wide SEO upgrade** → richer root metadata, hreflang alternates,
   per-page canonical + OG, JSON-LD Organization + WebSite + SoftwareApplication
   triple-graph, sitemap.ts, robots.ts, manifest.ts.

## What's NOT touched

- `portal/src/app/api/**` (any API route)
- `portal/src/lib/**` (Supabase clients, auth helpers, i18n dict)
- `portal/src/actions/**`, `portal/src/hooks/**`
- `portal/src/middleware.ts`
- `next.config.mjs`, `package.json`, `tsconfig.json`, `vercel.json`
- DB / Supabase migrations
- Stripe / OAuth / webhook handlers
- Form submit handlers, useState, useEffect, router.push, supabase.auth.*

Every single behavior-critical line is preserved verbatim. Only outer wrapper
classNames and *visual* elements changed.

## Files in this patch

```
patch/portal/
├── public/                      NEW · Twitter/X social assets
│   ├── og-cn.png                1200×630 Chinese OG card
│   ├── og-en.png                1200×630 English OG card
│   ├── cn.html / en.html        static meta entry points (crawler-friendly)
│   └── logo.png                 brand glyph (for OGCard re-render)
└── src/
    ├── components/landing/
    │   └── OGCard.jsx           NEW · 1200×630 card React source
    └── app/
        ├── layout.tsx           MODIFIED · upgraded metadata + JSON-LD graph
        ├── sitemap.ts           NEW · dynamic /sitemap.xml
        ├── robots.ts            NEW · dynamic /robots.txt
        ├── manifest.ts          NEW · PWA /manifest.webmanifest
        ├── og/[lang]/page.tsx   NEW · /og/cn /og/en (for regenerating PNGs)
        ├── (auth)/
        │   ├── layout.tsx       MODIFIED · noindex robots tag for login/signup
        │   ├── login/page.tsx   MODIFIED · dark-glass wrapper, cyan-gradient
        │   │                       title, glow CTA. Form logic unchanged.
        │   └── signup/page.tsx  MODIFIED · same dark-glass treatment.
        ├── (dashboard)/
        │   └── layout.tsx       MODIFIED · dark-glass background w/ grid + glow
        ├── admin/
        │   └── AdminDashboard.tsx  MODIFIED · dark-glass background, gradient
        │                              title, gradient refresh button.
        └── (marketing)/
            ├── cn/layout.tsx           MODIFIED · hreflang + og-cn.png + canonical
            ├── en/layout.tsx           NEW · English hreflang + og-en.png
            ├── pricing/layout.tsx      NEW · pricing canonical + OG
            ├── servers/layout.tsx      NEW · servers canonical + OG
            ├── download/layout.tsx     NEW · download canonical + OG
            ├── help/layout.tsx         NEW · help canonical
            ├── support/layout.tsx      NEW · support canonical
            ├── download/page.tsx       MODIFIED · gradient hero
            ├── privacy/page.tsx        MODIFIED · LandingChrome + gradient hero
            ├── terms/page.tsx          MODIFIED · LandingChrome + gradient hero
            ├── servers/page.tsx        MODIFIED · LandingChrome wrap
            ├── pricing/page.tsx        MODIFIED · LandingChrome wrap
            ├── disclaimer/page.tsx     MODIFIED · LandingChrome wrap
            ├── cookies/page.tsx        MODIFIED · LandingChrome wrap
            ├── help/page.tsx           MODIFIED · LandingChrome wrap
            ├── support/page.tsx        MODIFIED · LandingChrome wrap
            ├── blog/page.tsx           MODIFIED · LandingChrome wrap
            └── blog/[slug]/page.tsx    MODIFIED · LandingChrome wrap
```

## How to apply

```bash
cd /path/to/local/mirrorspeed
unzip -o ~/Downloads/mirrorspeed-portal-patch.zip
git status portal/                       # confirm scope is portal/-only
git diff portal/                         # review every change

# Optional: smoke test before commit
cd portal && yarn dev
# Verify in browser:
#   / · /cn · /en · /pricing · /servers · /download · /privacy · /terms
#   /help · /support · /cookies · /disclaimer · /blog
#   /login · /signup (logged out)
#   /dashboard · /admin (logged in)
#   /sitemap.xml · /robots.txt · /manifest.webmanifest

git add portal/
git commit -m "feat(web): unify all pages under dark-glass theme + comprehensive SEO upgrade

- All marketing/auth/dashboard/admin pages now share the dark-theme landing
  aesthetic. Form logic, API calls, auth handlers, middleware untouched.
- Bilingual Twitter/X OG cards (og-{cn,en}.png + {cn,en}.html static entries).
- New sitemap.ts, robots.ts, manifest.ts at app root.
- Per-page metadata layouts add hreflang alternates, canonical URLs,
  localized og:image, and twitter:card.
- Root layout: JSON-LD triple-graph (Organization + WebSite + SoftwareApplication)
  with aggregate rating, search action, og:locale alternates."
git push
```

## SEO checklist after deploy

1. **Search Console**: submit `/sitemap.xml` for both `mirrorspeed.com` and
   `www.mirrorspeed.com` properties.
2. **Bing Webmaster Tools**: submit `/sitemap.xml`.
3. **Twitter / X**: validate `mirrorspeed.com/cn.html` and `en.html` at
   https://cards-dev.twitter.com/validator (must be approved once per host).
4. **Facebook**: scrape https://developers.facebook.com/tools/debug/ to prime
   their cache.
5. **Schema validator**: https://validator.schema.org/ — paste your homepage
   URL, should show Organization + WebSite + SoftwareApplication detected.
6. **Lighthouse audit**: target ≥ 95 across Performance / Accessibility / Best
   Practices / SEO.
7. **PageSpeed Insights**: https://pagespeed.web.dev/?url=https://mirrorspeed.com
8. Once you have a Google verification code, paste it into
   `metadata.verification.google` in `src/app/layout.tsx`.

## Growth tips

- The robots.ts blocks `GPTBot`, `ClaudeBot`, `PerplexityBot` from `/api`,
  `/admin`, `/dashboard` but ALLOWS them on marketing pages — they will
  cite your site in their answers, driving high-intent referral traffic.
- The hreflang `x-default` pointing to `/` lets Google auto-route users to
  the right language version.
- `sitemap.ts` declares `/cn` and `/en` as language alternates so Google
  shows the localized result for each user's locale.
